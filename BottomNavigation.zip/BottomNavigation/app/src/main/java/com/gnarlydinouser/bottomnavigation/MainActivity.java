package com.gnarlydinouser.bottomnavigation;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNav = findViewById(R.id.bottomNavigation);
        bottomNav.setOnNavigationItemSelectedListener(navListener);
        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout,
                new home()).commit();
        // Display the default fragment

    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                    if(item.getItemId()==R.id.Home)
                        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout,
                                new home()).commit();
                    else if(item.getItemId()==R.id.Location)
                        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout,
                                new location()).commit();
                    else if(item.getItemId()==R.id.Chatbot)
                        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout,
                                new chatbot()).commit();
                    else if(item.getItemId()==R.id.Profile)
                        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout,
                                new profile()).commit();
                    return true;
                }
            };
}
